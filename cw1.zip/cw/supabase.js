import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm'

const supabaseUrl = 'https://qwxofdskvkjbqszkqozg.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF3eG9mZHNrdmtqYnFzemtxb3pnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDYyMDg2NzQsImV4cCI6MjA2MTc4NDY3NH0.bJqmBOGAq7-PHLYyvKk56Df27BB7YUe2ZPzsXJOjC5Q'

export const supabase = createClient(supabaseUrl, supabaseKey)
