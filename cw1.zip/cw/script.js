import { supabase } from './supabase.js'

document.addEventListener('DOMContentLoaded', () => {
  const peopleForm = document.getElementById('search-form')
  const vehicleForm = document.getElementById('vehicle-form')
  const message = document.getElementById('message')
  const results = document.getElementById('results')

  if (peopleForm) {
    peopleForm.addEventListener('submit', async (e) => {
      e.preventDefault()
      results.innerHTML = ''
      message.textContent = ''

      const name = document.getElementById('name').value.trim().toLowerCase()
      const license = document.getElementById('license').value.trim().toUpperCase()

      if (!name && !license) {
        message.textContent = 'Error: Both fields are empty'
        return
      }

      if (name && license) {
        message.textContent = 'Error: Only one field should be filled'
        return
      }

      let query = supabase.from('people').select('*')
      if (name) {
        query = query.ilike('Name', `%${name}%`)
      } else {
        query = query.ilike('LicenseNumber', `%${license}%`)
      }

      const { data, error } = await query

      if (error) {
        message.textContent = 'Error fetching data'
        return
      }

      if (data.length === 0) {
        message.textContent = 'No result found'
        return
      }

      message.textContent = 'Search successful'

      data.forEach(person => {
        const div = document.createElement('div')
        div.innerHTML = `
          <p><strong>Name:</strong> ${person.Name}</p>
          <p><strong>Address:</strong> ${person.Address}</p>
          <p><strong>DOB:</strong> ${person.DOB}</p>
          <p><strong>License:</strong> ${person.LicenseNumber}</p>
          <p><strong>Expiry:</strong> ${person.ExpiryDate}</p>
          <hr>
        `
        results.appendChild(div)
      })
    })
  }

  if (vehicleForm) {
    vehicleForm.addEventListener('submit', async (e) => {
      e.preventDefault()
      results.innerHTML = ''
      message.textContent = ''

      const rego = document.getElementById('rego').value.trim().toUpperCase()

      if (!rego) {
        message.textContent = 'Error: Registration number is empty'
        return
      }

      const { data: vehicles, error } = await supabase
        .from('vehicles')
        .select('*')
        .eq('VehicleID', rego)

      if (error || !vehicles || vehicles.length === 0) {
        message.textContent = 'No result found'
        return
      }

      const vehicle = vehicles[0]

      let ownerInfo = '<p><strong>Owner:</strong> Unknown</p>'
      if (vehicle.OwnerID) {
        const { data: owners } = await supabase
          .from('people')
          .select('*')
          .eq('PersonID', vehicle.OwnerID)

        if (owners && owners.length > 0) {
          ownerInfo = `
            <p><strong>Owner:</strong> ${owners[0].Name}</p>
            <p><strong>License:</strong> ${owners[0].LicenseNumber}</p>
          `
        }
      }

      message.textContent = 'Search successful'

      const div = document.createElement('div')
      div.innerHTML = `
        <p><strong>Make:</strong> ${vehicle.Make}</p>
        <p><strong>Model:</strong> ${vehicle.Model}</p>
        <p><strong>Colour:</strong> ${vehicle.Colour}</p>
        ${ownerInfo}
        <hr>
      `
      results.appendChild(div)
    })
  }
})
let currentOwnerId = null

const checkOwnerBtn = document.getElementById('check-owner')
const ownerResults = document.getElementById('owner-results')
const newOwnerBtn = document.getElementById('new-owner')
const newOwnerForm = document.getElementById('new-owner-form')
const addOwnerBtn = document.getElementById('add-owner')
const addVehicleBtn = document.getElementById('add-vehicle')
const ownerMessage = document.getElementById('message-owner')
const vehicleMessage = document.getElementById('message-vehicle')

if (checkOwnerBtn) {
  checkOwnerBtn.addEventListener('click', async () => {
    ownerResults.innerHTML = ''
    ownerMessage.textContent = ''
    newOwnerForm.style.display = 'none'
    newOwnerBtn.style.display = 'none'
    addVehicleBtn.style.display = 'none'
    currentOwnerId = null

    const ownerName = document.getElementById('owner').value.trim()
    if (!ownerName) {
      return
    }

    const { data, error } = await supabase
      .from('people')
      .select('*')
      .ilike('Name', `%${ownerName}%`)

    if (error) {
      ownerMessage.textContent = 'Error'
      return
    }

    if (!data || data.length === 0) {
      newOwnerBtn.style.display = 'inline'
      return
    }

    newOwnerBtn.style.display = 'inline'

    data.forEach(person => {
      const div = document.createElement('div')
      div.innerHTML = `
        <p><strong>${person.Name}</strong> (${person.Address}, ${person.DOB})</p>
        <button class="select-owner" data-id="${person.PersonID}">Select owner</button>
        <hr>
      `
      ownerResults.appendChild(div)
    })

    document.querySelectorAll('.select-owner').forEach(btn => {
      btn.addEventListener('click', (e) => {
        currentOwnerId = parseInt(e.target.dataset.id)
        addVehicleBtn.style.display = 'inline'
      })
    })
  })
}

if (newOwnerBtn) {
  newOwnerBtn.addEventListener('click', () => {
    newOwnerForm.style.display = 'block'
  })
}

if (addOwnerBtn) {
  addOwnerBtn.addEventListener('click', async () => {
    ownerMessage.textContent = ''
    const name = document.getElementById('name').value.trim()
    const address = document.getElementById('address').value.trim()
    const dob = document.getElementById('dob').value.trim()
    const license = document.getElementById('license').value.trim()
    const expire = document.getElementById('expire').value.trim()

    if (!name || !address || !dob || !license || !expire) {
      ownerMessage.textContent = 'Error: All fields required'
      return
    }

    const { data: existing } = await supabase
      .from('people')
      .select('*')
      .eq('Name', name)
      .eq('Address', address)
      .eq('DOB', dob)
      .eq('LicenseNumber', license)
      .eq('ExpiryDate', expire)

    if (existing && existing.length > 0) {
      ownerMessage.textContent = 'Error: Duplicate owner'
      return
    }

    const { data, error } = await supabase
      .from('people')
      .insert([{ Name: name, Address: address, DOB: dob, LicenseNumber: license, ExpiryDate: expire }])
      .select()

    if (error) {
      ownerMessage.textContent = 'Error'
      return
    }

    currentOwnerId = data[0].PersonID
    ownerMessage.textContent = 'Owner added successfully'
    addVehicleBtn.style.display = 'inline'
  })
}

if (addVehicleBtn) {
  addVehicleBtn.addEventListener('click', async () => {
    vehicleMessage.textContent = ''
    const rego = document.getElementById('rego').value.trim()
    const make = document.getElementById('make').value.trim()
    const model = document.getElementById('model').value.trim()
    const colour = document.getElementById('colour').value.trim()

    if (!rego || !make || !model || !colour || !currentOwnerId) {
      vehicleMessage.textContent = 'Error: Missing fields'
      return
    }

    const { error } = await supabase
      .from('vehicles')
      .insert([{ VehicleID: rego, Make: make, Model: model, Colour: colour, OwnerID: currentOwnerId }])

    if (error) {
      vehicleMessage.textContent = 'Error'
    } else {
      vehicleMessage.textContent = 'Vehicle added successfully'
    }
  })
}
